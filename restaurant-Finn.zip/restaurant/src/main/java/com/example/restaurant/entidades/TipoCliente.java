package com.example.restaurant.entidades;

public enum TipoCliente {
    particular, empresa, pension
}
