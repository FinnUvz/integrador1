rootProject.name = "restaurant"
