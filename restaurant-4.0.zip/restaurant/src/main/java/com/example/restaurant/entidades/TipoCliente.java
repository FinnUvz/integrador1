package com.example.restaurant.entidades;

public enum TipoCliente {
	
    PARTICULAR,
    PENSION,
    EMPRESA
}
