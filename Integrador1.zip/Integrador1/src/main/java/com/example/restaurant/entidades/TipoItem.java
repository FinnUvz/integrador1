package com.example.restaurant.entidades;

public enum TipoItem {
    COMIDA, BEBIDA, ENTRADA
}
