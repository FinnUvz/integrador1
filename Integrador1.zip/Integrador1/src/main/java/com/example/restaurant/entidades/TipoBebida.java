package com.example.restaurant.entidades;

public enum TipoBebida {
    gaseosa, jugo
}
