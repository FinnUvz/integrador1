package com.example.restaurant.entidades;

public enum TipoComida {
    plato, entrada
}

